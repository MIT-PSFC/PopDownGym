import numpy as np

def to_numpy(arr):
    if len(arr.size) > 1:
        # For whatever reason, matlab.engine doesn't support toarray() on multidimensional arrays.
        return np.array(arr.tomemoryview().tolist())
    else:
        return np.array(arr.toarray())

def numpy_to_matlab(arr):
    return matlab.double(arr.tolist())