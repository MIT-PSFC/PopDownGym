import os
import matlab.engine
from scipy.interpolate import interp1d
from rd_rl.raptor.utils import to_numpy

def init_matlab(raptor_repo_root: str) -> matlab.engine.MatlabEngine:
    """ Initialize an MatlabEngine instance and add project-relevant paths.

    Args:
        raptor_repo_root (str): directory of the raptor repository.

    Returns:
        matlab.engine.MatlabEngine: matlab engine handle.
    """
    eng = matlab.engine.start_matlab()
    raptor_path_file = os.path.join(raptor_repo_root, "RAPTOR_path.m")
    eng.run(raptor_path_file, nargout=0)
    genpath = eng.genpath(os.path.join(raptor_repo_root, "projects", "SPARC"))
    eng.addpath(genpath, nargout=0)
    return eng

def init_sparc_rd(eng: matlab.engine.MatlabEngine):
    eng = matlab.engine.start_matlab()
    x0, g, v, U0, model, params, simres, out0, config = eng.init_raptor(nargout=9)

    g = to_numpy(g)
    v = to_numpy(v)
    U0 = to_numpy(U0)
    tgrid = params['tgrid'].clone()
    ntotal_steps = tgrid.size[1]

    # Get g as a function of Ip.
    Ip = U0[0, :]
    g_interp = interp1d(Ip, g)
    Vp = eng.eval_Vp([], matlab.double(g.tolist()), [], model, True)
    Vp_interp = interp1d(Ip, to_numpy(Vp))
    raptor_steps_per_step = 5


if __name__ == "__main__":
    eng_handle = init_matlab("/home/awang/raptor")